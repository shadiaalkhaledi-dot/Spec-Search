# 2026-08-07 — YYC Concourse B, Tender Package 5

Source: `YYC_Concourse B_Package 5_BID_AR.pdf` (81 sheets), `CAA Domestic Restoration Concourse B
TP5 Vol 1 - AR.pdf` (593 pages). 51 technical sections issued.

## Added (18)

Each verified: term present on the drawings, section present in the issued spec list.

| term | section |
|---|---|
| fire stopping | 07 84 00 Firestopping |
| paint | 09 91 00 Painting |
| painted | 09 91 00 Painting |
| signage | 10 14 00 Signage |
| gfrc | 03 49 00 Glass-Fibre-Reinforced Concrete |
| grc | 03 49 00 Glass-Fibre-Reinforced Concrete |
| access panel | 08 31 00 Access Doors and Panels |
| access panels | 08 31 00 Access Doors and Panels |
| access door | 08 31 00 Access Doors and Panels |
| steel stud framing | 09 22 16 Non-Structural Metal Stud Framing |
| stud framing | 09 22 16 Non-Structural Metal Stud Framing |
| plywood backing | 09 28 11 Backing Boards |
| roller shade | 12 24 13 Roller Window Shades |
| roller shades | 12 24 13 Roller Window Shades |
| fire extinguisher cabinet | 10 44 13 Fire Protection Cabinet |
| extinguisher cabinet | 10 44 13 Fire Protection Cabinet |
| polished concrete | 03 35 43 Polished Concrete Finishing |
| shaft wall | 09 21 16-23 Gypsum Board Shaft Wall Assemblies |

## Rejected by validation (2)

Target section absent from `sections`; would have created a dangling reference.

- `toilet partition` -> 10 21 13.09
- `stone veneer` -> 04 43 13

## Declined on judgement

- `acoustic insulation` -> 09 81 29. The drawings show batt insulation, section 09 81 29 is
  *sprayed*. Needs a decision before mapping.
- Generic single words proposed by extraction (`metal`, `floor`, `concrete`, `masonry`, `aluminum`,
  `sliding`) — too broad, would create false positives.

## Effect

Recall 43% -> 63%. Precision 23.9% -> 31.4%. Evaluation set 78.5% -> 100%.

## Follow-up

Add the 8 missing sections to `sections`, then curate terms for them.
