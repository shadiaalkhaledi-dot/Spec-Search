# 2026-08-07 — YYC Concourse B, Tender Package 5

Source: `YYC_Concourse B_Package 5_BID_AR.pdf` (81 sheets), `CAA Domestic Restoration Concourse B
TP5 Vol 1 - AR.pdf` (593 pages). 51 technical sections issued.

## Added (18)

Each verified: term present on the drawings, section present in the issued spec list.

| term | section |
|---|---|
| fire stopping | 07 84 00 Firestopping |
| paint | 09 91 00 Painting |
| painted | 09 91 00 Painting |
| signage | 10 14 00 Signage |
| gfrc | 03 49 00 Glass-Fibre-Reinforced Concrete |
| grc | 03 49 00 Glass-Fibre-Reinforced Concrete |
| access panel | 08 31 00 Access Doors and Panels |
| access panels | 08 31 00 Access Doors and Panels |
| access door | 08 31 00 Access Doors and Panels |
| steel stud framing | 09 22 16 Non-Structural Metal Stud Framing |
| stud framing | 09 22 16 Non-Structural Metal Stud Framing |
| plywood backing | 09 28 11 Backing Boards |
| roller shade | 12 24 13 Roller Window Shades |
| roller shades | 12 24 13 Roller Window Shades |
| fire extinguisher cabinet | 10 44 13 Fire Protection Cabinet |
| extinguisher cabinet | 10 44 13 Fire Protection Cabinet |
| polished concrete | 03 35 43 Polished Concrete Finishing |
| shaft wall | 09 21 16-23 Gypsum Board Shaft Wall Assemblies |

## Rejected by validation (2)

Target section absent from `sections`; would have created a dangling reference.

- `toilet partition` -> 10 21 13.09
- `stone veneer` -> 04 43 13

## Declined on judgement

- `acoustic insulation` -> 09 81 29. The drawings show batt insulation, section 09 81 29 is
  *sprayed*. Needs a decision before mapping.
- Generic single words proposed by extraction (`metal`, `floor`, `concrete`, `masonry`, `aluminum`,
  `sliding`) — too broad, would create false positives.

## Effect

Recall 43% -> 63%. Precision 23.9% -> 31.4%. Evaluation set 78.5% -> 100%.

## Follow-up

Add the 8 missing sections to `sections`, then curate terms for them.

---

## Second pass — corrections from user review

Two results were flagged as wrong on inspection. Both were real, and both were a class the automated
pass could not have caught.

### 1. `stud framing` -> `06 10 00 Rough Carpentry`

Rough Carpentry is a wood section. On this package the drawings say **"steel stud" 47 times and
"wood stud" zero times**, and `06 10 00` was **not issued** (`06 10 53` was). Mapping removed.
`wood stud` and `wood stud framing` added pointing at `06 10 53`, so the wood case stays reachable
when it is genuinely wood.

### 2. `solid surfacing material` -> `06 40 00 Shop Fabricated Architectural Woodwork`

`06 61 16 Solid Surfacing Fabrications` exists and **was issued on this project**. The library was
already inconsistent with itself — `solid surface` and `solid surfacing sheet` pointed at `06 61 16`
while `solid surfacing material` pointed at woodwork. Retargeted. `corian` added.
Bare `fabric` also removed from `06 40 00` — a generic word producing misleading attribution.

`toilet partition`, `toilet partitions` and `toilet compartment` added pointing at `10 21 13`. The
spec TOC lists `10 21 13.09`, which does not exist in the library; the parent does.

### A bug in the curation tooling

The first pass rejected `stone veneer` and `toilet partition` reporting "section not in library".
That was wrong — the code canonicaliser mangled `-00` suffixes, so `04 43 13-00` normalised to
`04 43 13-0` and failed to match. Fixed. Validation failing loudly is what made this visible.

### The evaluation set was also wrong

Two cases were generated from "term appears on drawings AND section was issued", which encodes
correlation as truth. Both flagged mappings were in the set as *expected* results. Corrected, and a
negative assertion added: `stud framing` must return `09 22 16` and must not return `06 10 00`.

**The evaluation set needs curating like any other data.** Auto-generation seeds it; judgement
fixes it.

### Effect of the second pass

| | first pass | after corrections |
|---|---|---|
| Recall | 63% | **65%** |
| Precision | 31.4% | **32.4%** |
| Evaluation cases | 79 | 80, all passing |
