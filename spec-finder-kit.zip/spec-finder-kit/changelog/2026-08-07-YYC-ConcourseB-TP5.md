# 2026-08-07 — YYC Concourse B, Tender Package 5

Source: `YYC_Concourse B_Package 5_BID_AR.pdf` (81 sheets), `CAA Domestic Restoration Concourse B
TP5 Vol 1 - AR.pdf` (593 pages). 51 technical sections issued.

## Added (18)

Each verified: term present on the drawings, section present in the issued spec list.

| term | section |
|---|---|
| fire stopping | 07 84 00 Firestopping |
| paint | 09 91 00 Painting |
| painted | 09 91 00 Painting |
| signage | 10 14 00 Signage |
| gfrc | 03 49 00 Glass-Fibre-Reinforced Concrete |
| grc | 03 49 00 Glass-Fibre-Reinforced Concrete |
| access panel | 08 31 00 Access Doors and Panels |
| access panels | 08 31 00 Access Doors and Panels |
| access door | 08 31 00 Access Doors and Panels |
| steel stud framing | 09 22 16 Non-Structural Metal Stud Framing |
| stud framing | 09 22 16 Non-Structural Metal Stud Framing |
| plywood backing | 09 28 11 Backing Boards |
| roller shade | 12 24 13 Roller Window Shades |
| roller shades | 12 24 13 Roller Window Shades |
| fire extinguisher cabinet | 10 44 13 Fire Protection Cabinet |
| extinguisher cabinet | 10 44 13 Fire Protection Cabinet |
| polished concrete | 03 35 43 Polished Concrete Finishing |
| shaft wall | 09 21 16-23 Gypsum Board Shaft Wall Assemblies |

## Rejected by validation (2)

Target section absent from `sections`; would have created a dangling reference.

- `toilet partition` -> 10 21 13.09
- `stone veneer` -> 04 43 13

## Declined on judgement

- `acoustic insulation` -> 09 81 29. The drawings show batt insulation, section 09 81 29 is
  *sprayed*. Needs a decision before mapping.
- Generic single words proposed by extraction (`metal`, `floor`, `concrete`, `masonry`, `aluminum`,
  `sliding`) — too broad, would create false positives.

## Effect

Recall 43% -> 63%. Precision 23.9% -> 31.4%. Evaluation set 78.5% -> 100%.

## Follow-up

Add the 8 missing sections to `sections`, then curate terms for them.

---

## Second pass — corrections from user review

Two results were flagged as wrong on inspection. Both were real, and both were a class the automated
pass could not have caught.

### 1. `stud framing` -> `06 10 00 Rough Carpentry`

Rough Carpentry is a wood section. On this package the drawings say **"steel stud" 47 times and
"wood stud" zero times**, and `06 10 00` was **not issued** (`06 10 53` was). Mapping removed.
`wood stud` and `wood stud framing` added pointing at `06 10 53`, so the wood case stays reachable
when it is genuinely wood.

### 2. `solid surfacing material` -> `06 40 00 Shop Fabricated Architectural Woodwork`

`06 61 16 Solid Surfacing Fabrications` exists and **was issued on this project**. The library was
already inconsistent with itself — `solid surface` and `solid surfacing sheet` pointed at `06 61 16`
while `solid surfacing material` pointed at woodwork. Retargeted. `corian` added.
Bare `fabric` also removed from `06 40 00` — a generic word producing misleading attribution.

`toilet partition`, `toilet partitions` and `toilet compartment` added pointing at `10 21 13`. The
spec TOC lists `10 21 13.09`, which does not exist in the library; the parent does.

### A bug in the curation tooling

The first pass rejected `stone veneer` and `toilet partition` reporting "section not in library".
That was wrong — the code canonicaliser mangled `-00` suffixes, so `04 43 13-00` normalised to
`04 43 13-0` and failed to match. Fixed. Validation failing loudly is what made this visible.

### The evaluation set was also wrong

Two cases were generated from "term appears on drawings AND section was issued", which encodes
correlation as truth. Both flagged mappings were in the set as *expected* results. Corrected, and a
negative assertion added: `stud framing` must return `09 22 16` and must not return `06 10 00`.

**The evaluation set needs curating like any other data.** Auto-generation seeds it; judgement
fixes it.

### Effect of the second pass

| | first pass | after corrections |
|---|---|---|
| Recall | 63% | **65%** |
| Precision | 31.4% | **32.4%** |
| Evaluation cases | 79 | 80, all passing |

---

## Third pass — closing the gaps

**Eight sections added to `sections`.** Every section issued on this project now exists in the
library: `07 42 50` Metal Column Cladding, `07 95 13` Interior Expansion Control, `08 34 56` Security
Gates, `08 71 10` Door Hardware Schedule, `09 54 00` Specialty Ceilings, `10 20 00` Interior
Specialties, `10 26 13` Corner Guards, `27 41 16` Integrated Audio Visual Systems. Twelve terms
mapped to them.

**Five mis-targeted mappings retargeted** from a generic parent to the specific issued section:
`expansion joint` and `movement joint` from `07 95 00` to `07 95 13`; `igu` and `mgu` from
`08 81 00` to `08 81 13`; `corner guard` from `10 26 23-13` to `10 26 13`.

**Manufacturers extracted from the spec volume.** 20 names added across 6 sections, parsed from the
"Acceptable Manufacturers" blocks — Firestopping and Joint Sealants had none at all before. Note the
extraction still lets through the occasional product code (`TC-417`, `Acudor DW-5015`) or company
fragment (`A USG Company`); worth a manual read of `analysis/mfr-added.json`.

**`scanConf` retuned against ground truth.** Previously the weights were a guess. Sweeping them
against what was actually issued found a far better operating point, and the decisive change is that
**single generic words now carry zero evidential weight** — only multi-word phrases count, with the
threshold raised to 7.

| scan "LIKELY" badge | before | after |
|---|---|---|
| sections badged | 94 | 22 |
| of which genuinely issued | 36 | 19 |
| **precision** | **38.3%** | **86.4%** |
| recall | 100% | 52.8% |

A big trade, and the right one here: demoted sections are still shown, just unbadged, while a false
"required" sends someone hunting for a specification that does not exist.

**Caveat: these weights are tuned on one project.** Eight parameters fitted to a single building is
textbook overfitting. The chosen point sits on a plateau rather than a spike, which is mildly
reassuring, but re-validate on the next package before trusting it.

**Feedback flags can now leave the browser.** `FLAG_ENDPOINT` at the top of the script — set it to an
Apps Script web app or any POST collector and flags are sent as they are raised. Left empty, the app
behaves exactly as before. localStorage stays the source of truth, so a failed send loses nothing.

**CI added.** `.github/workflows/eval.yml` runs on every push touching `data.js` or `index.html`:
checks for dangling alias targets, verifies `kwByCode` is derivable from `aliases`, confirms the
data/code split is intact, then runs the evaluation set.

## Where this project ended up

| | start | end |
|---|---|---|
| Recall | 43% | **71%** |
| Precision (library reach) | 23.9% | **35.3%** |
| Scan badge precision | 38.3% | **86.4%** |
| Sections issued but missing from the library | 8 | **0** |
| Evaluation set | — | **80 cases, passing** |
