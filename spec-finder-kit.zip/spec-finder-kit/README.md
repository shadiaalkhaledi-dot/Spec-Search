# Spec Finder — project kit

Everything needed to run the Spec Finder learning loop. Attach this to a Cowork project for
`shadiaalkhaledi-dot/Spec-Search`.

## What is in here

```
app/index.html      the application. 78 KB. contains no spec content.
app/data.js         the spec library. 464 sections, 3,268 aliases. this is what curation edits.
eval/               the evaluation set and its runner. run before every commit.
docs/               how the app works, how the loop works, what to curate next, and the first
                    measured proof of concept.
changelog/          which project taught which alias. provenance for rollback.
skill/              reference copy of the spec-library-curator skill.
```

## Start here

1. `docs/02-learning-loop-blueprint.md` — what the loop is and how a project becomes an update.
2. `docs/04-proof-of-concept.md` — the first real run, with numbers.
3. `docs/01-architecture-map.md` — how the app works, when you need to change behaviour.

## The one rule

`index.html` and `data.js` must be deployed together, in the same folder, in the same commit.
`index.html` will show a plain error message rather than a blank page if `data.js` is missing, but
a commit that adds one without the other still breaks the site for the gap.

## Current state

| | |
|---|---|
| Recall on the one project measured | 63% |
| Precision on that project | 31.4% |
| Evaluation set | 79 cases, passing |
| Sections with no alias reaching them | 11 known, plus 8 sections missing entirely |

Recall is the number to drive down. It is now measurable, which it was not before.

## Doing a curation pass

Invoke the `spec-library-curator` skill with a finished project's drawings and its issued spec list.
The procedure: baseline first, four-bucket classification, script-not-hand edits, `kwByCode` rebuilt
from `aliases`, evaluation set run before commit, changelog entry for provenance.
