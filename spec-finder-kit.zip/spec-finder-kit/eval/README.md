# Evaluation set

`evaluation-set.json` — 75 positive cases and 4 negative cases. Each positive case is a term that
appeared on a real drawing set paired with a section that was actually issued on that project. Each
negative case is a term that must return no curated section.

Run it against any version of the library:

```
node eval/eval.js app/data.js eval/evaluation-set.json
```

Exit code 0 means every case passed. Non-zero prints the failures.

**Run this before every commit to `data.js`.** A curation pass that lowers the score has made the
app worse, whatever else it did.

Grow the set with every project — the goal is a few hundred cases spanning several buildings.
Cases from a single project overfit to that project's vocabulary.
