#!/usr/bin/env node
/* Score a data.js against the evaluation set.  usage: node eval.js [data.js] [evaluation-set.json] */
const fs=require("fs"),path=require("path");
const dataFile=process.argv[2]||path.join(__dirname,"..","data.js");
const evalFile=process.argv[3]||path.join(__dirname,"evaluation-set.json");
const DB=new Function(fs.readFileSync(dataFile,"utf8")+"\n; return DB;")();
const canon=(c)=>c.trim().replace(/\./g,"-").replace(/-0+(\d)/,"-$1").replace(/-00$/,"");
const norm=(s)=>s.toLowerCase().replace(/[^a-z0-9 ]/g," ").replace(/\s+/g," ").trim();
const sing=(w)=>(w.length>3&&w.endsWith("s")?w.slice(0,-1):w);
const byCode={}; DB.sections.forEach(s=>byCode[s.code]=s);
function curated(query){                       // mirrors lookup()'s alias-backed path
  const qt=norm(query).split(" ").map(sing).filter(Boolean);
  const tok=(w,a)=>a.some(x=>x===w||(w.length>=4&&x.length>=4&&(x.startsWith(w)||w.startsWith(x))));
  const out=new Set();
  for(const term in DB.aliases){
    const tt=norm(term).split(" ").map(sing).filter(Boolean);
    if(tt.length&&tt.every(w=>tok(w,qt))) DB.aliases[term].forEach(c=>out.add(canon(c)));
  }
  return out;
}
const E=JSON.parse(fs.readFileSync(evalFile,"utf8"));
let pass=0,fail=[];
for(const c of E.cases){
  const got=curated(c.term);
  if(c.expectNoCuratedMatch){ got.size===0?pass++:fail.push([c.term,"expected nothing",[...got].slice(0,3).join(",")]); continue; }
  const want=c.expect.map(canon);
  want.every(w=>got.has(w)) ? pass++ : fail.push([c.term,want.join(","),[...got].slice(0,4).join(",")||"(nothing)"]);
}
const total=E.cases.length;
console.log(`evaluation: ${pass}/${total} passed  (${(pass/total*100).toFixed(1)}%)`);
if(fail.length){ console.log("\nfailures:"); fail.slice(0,25).forEach(f=>console.log(`  ${f[0].padEnd(28)} want ${f[1].padEnd(24)} got ${f[2]}`)); }
process.exit(fail.length?1:0);
