# tools

`provenance.js` — what the library knows about itself. Run it any time:

```
node tools/provenance.js data.js
```

Reports how many alias edges have a recorded origin, how many have been corroborated by a project
and by how many, what has been retired or declined, and what each project contributed.

## What the fields mean

**edges** — where a mapping came from. Only populated from the point provenance tracking started.

**unrecorded** — everything older. These were largely derived from earlier projects and
specifications; the source simply was not captured at the time. *Unrecorded is not unverified.*

**confirmations** — projects that independently corroborate an edge: the term appeared on that
project's drawings and the section was in its issued list. This is the trust signal, and it is more
useful than origin. One project corroborates roughly 4% of the library, so it climbs slowly.

**review** — a project whose drawings carried the term but which issued a *sibling* section instead.
A correction candidate, not proof of error.

**retired / declined** — decisions already made, with reasons. The curation process reads these
before proposing, so a rejected mapping is never put in front of you twice.
