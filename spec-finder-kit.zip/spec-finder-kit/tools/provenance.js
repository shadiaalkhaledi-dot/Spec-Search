#!/usr/bin/env node
/* Provenance report.  usage: node tools/provenance.js [data.js] */
const fs=require("fs"),path=require("path");
const f=process.argv[2]||path.join(__dirname,"..","data.js");
const DB=new Function(fs.readFileSync(f,"utf8")+"\n; return DB;")();
const p=DB.provenance||{edges:{},retired:{},declined:{},confirmations:{},review:{}};
let edges=0; for(const t in DB.aliases) edges+=DB.aliases[t].length;
const conf=p.confirmations||{};
const byN={}; Object.values(conf).forEach(v=>{const n=v.length;byN[n]=(byN[n]||0)+1;});
console.log("LIBRARY");
console.log("  sections",DB.sections.length,"| alias terms",Object.keys(DB.aliases).length,"| alias edges",edges);
console.log("\nPROVENANCE");
console.log("  edges with a recorded origin :",Object.keys(p.edges||{}).length);
console.log("  edges never recorded         :",edges-Object.keys(p.edges||{}).length,"(pre-tracking; source not captured, not unverified)");
console.log("  edges corroborated by >=1 project:",Object.keys(conf).length);
Object.keys(byN).sort().forEach(n=>console.log(`      confirmed by ${n} project(s): ${byN[n]}`));
console.log("  flagged for review           :",Object.keys(p.review||{}).length);
console.log("\nDECISIONS (so they are never re-proposed)");
console.log("  retired  :",Object.keys(p.retired||{}).length);
console.log("  declined :",Object.keys(p.declined||{}).length);
console.log("\nPROJECTS");
for(const [id,v] of Object.entries(DB.projects||{})){
  console.log(`  ${id}  ${v.name}`);
  console.log(`      ${v.date} · ${v.sheets} sheets · ${v.issuedSections} sections issued · ${v.discipline}`);
  console.log(`      contributed: ${Object.entries(v.contributed).map(([k,n])=>k+" "+n).join(", ")}`);
}
const covered=Object.keys(conf).length, pct=(covered/edges*100).toFixed(1);
console.log(`\nCOVERAGE: ${pct}% of alias edges have been corroborated by at least one project.`);
console.log("One project touches roughly 4% of the library, so this climbs slowly and by design.");
