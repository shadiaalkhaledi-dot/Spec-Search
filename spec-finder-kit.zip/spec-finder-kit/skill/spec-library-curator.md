---
name: "spec-library-curator"
description: "Improve the Spec Finder keyword library (data.js) from a finished project's drawings and its issued spec list. Use for the Spec-Search learning loop — adding aliases, fixing false positives, or auditing coverage before uploading to the site."
---

# Spec Library Curator

Maintains the curated keyword library behind **Spec Finder**
(`shadiaalkhaledi-dot/Spec-Search`, GitHub Pages). Use whenever a finished project's drawings and
its actually-issued specification list are available and should be folded into the library, or when
false positives need diagnosing.

## The two-part system

1. **Runtime** — a user uploads a drawing set; the app maps drawing terminology to required
   MasterFormat sections and acceptable manufacturers.
2. **Learning loop** — after a project closes, its drawings plus its real issued spec list are used
   to improve `data.js`, which is then committed. This skill is part 2.

## Repository shape

| File | Role |
|---|---|
| `index.html` | Application code only. ~77 KB. **Contains no spec content.** |
| `data.js` | The entire spec library. Data only. This is what curation edits. |

`data.js` declares one global:

```js
const DB = {
  sections: [ { code, title, div, divName, mfr: [], bod: [] } ],  // MasterFormat sections
  aliases:  { "drawing term": ["03 11 13", ...] },                // curated mapping — the asset
  kwByCode: { "03 11 13": ["drawing term", ...] }                 // reverse index of aliases
};
```

Keys in `aliases` and `kwByCode` are sorted so diffs stay readable. **Keep them sorted.**

## The rule that makes curation matter

A result is badged **"required specification"** only when it came from `aliases`. Title-text matches
are shown separately as unbadged suggestions and can never be presented as required.

This means the library is the single source of truth for what the app asserts. It also means a term
missing from `aliases` produces "no curated match" rather than a wrong answer — which is the intended
behaviour, and the signal that curation is needed.

## Procedure

### 1. Establish the baseline before changing anything

Load `data.js` and report: section count, alias count, `kwByCode` count, and how many sections have
at least one alias. Never edit before this is on the record.

### 2. Extract evidence from the project

From the drawings, collect the terms that actually appear — including abbreviations (`HM`, `IGU`,
`SCW`, `CMU`, `GWB`). From the issued spec list, collect the section codes actually used.

The valuable pairing is **term → section that was genuinely issued for it on this project**. That is
ground truth. Anything else is a guess and must be labelled as one.

### 3. Classify each candidate before proposing it

- **Confirmed** — the term appears on the drawings and the matching section was issued. Add it.
- **Plausible** — the term appears but no clearly corresponding section was issued. Propose, flag as
  unconfirmed, do not add without a decision.
- **Contradicted** — an existing alias points at a section this project did *not* issue where it
  should have. Candidate for removal; raise it, never delete silently.

### 4. Prefer specific terms, but do not neglect common ones

Multi-word phrases (`cavity wall insulation`) are strong evidence and score higher at runtime.
Single generic words (`glass`, `door`, `concrete`) are weak, but if they are absent entirely the user
gets nothing at all for the words they most often type. Both are needed; keep them distinguishable.

A single word mapping to more than three or four sections is a signal the mapping is too broad —
prefer qualifying it (`tempered glass`) over letting one word fan out.

### 5. Apply edits programmatically, never by hand

Hand-editing a 439 KB data file corrupts it. Write a script that:

- loads `data.js`, applies additions and removals to `aliases`
- rebuilds `kwByCode` from `aliases` so the two cannot drift
- verifies every code referenced exists in `sections` — fail loudly on any that does not
- re-sorts keys
- writes `data.js` back with the header comment intact

### 6. Regression-test before committing

Extract `lookup()` from `index.html` into a headless harness, then run it against the library before
and after. Report:

- mean sections badged required per query across a sample of real alias terms
- any query whose result set changed, and whether that change was intended
- any term that previously returned a curated result and now returns none

An unexplained change in either direction means stop and investigate.

### 7. Record what happened

Append to a changelog: project name, date, terms added, terms removed, terms deliberately declined
and why. Without provenance there is no way to roll back one project's contribution later.

## Diagnosing false positives

If the app is returning sections that are not actually required:

1. Determine whether the bad result was **alias-backed or title-only**. Check the `viaAlias` flag on
   the result. Title-only results are unbadged by design and are not library defects.
2. If alias-backed, find the offending alias — usually one of: a single generic word fanning out to
   many codes, or `tokMatch` prefix-matching at four or more characters (`wall` reaching
   `wallcovering`).
3. Fix in the data first. Only change matching logic when no data fix is possible, and re-run the
   regression test.

## Things that will bite

- `String.replace` with a **string** replacement interprets `$&`, `$1`, `` $` ``. Always use a
  function replacement when inserting generated content. This has already caused one silent
  data-loss bug in this repo.
- `sing()` strips a trailing `s` from any word over three characters, so `glass` normalises to
  `glas`. Applied symmetrically to queries and aliases, so it is usually harmless — but do not add
  aliases that only work because of it.
- `esc()` output goes into HTML attributes. Anything user-supplied must stay escaped.
- The app is entirely client-side with no network calls. Feedback flags never leave the browser
  unless exported by hand, so flagged errors will not appear anywhere until someone exports them.

