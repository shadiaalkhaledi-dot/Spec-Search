# Proof of concept — YYC Concourse B, Tender Package 5

First end-to-end run of the learning loop against a real project. This is the measurement the
system did not previously have.

## Inputs

| | |
|---|---|
| Drawings | `YYC_Concourse B_Package 5_BID_AR.pdf` — 81 sheets at A0 |
| Specifications | `CAA Domestic Restoration Concourse B TP5 Vol 1 - AR.pdf` — 593 pages |
| Ground truth | 90 sections parsed from the spec table of contents; 51 technical (excluding Divisions 0 and 1) |

## What the run does

1. Extract text from both PDFs.
2. Parse the issued section list from the spec table of contents. This is ground truth.
3. Build 1- to 4-gram sets from the drawing text.
4. Test every one of the curated alias terms for presence on the drawings.
5. Compare the sections those terms reach against the sections actually issued.

## Result before curation

| | |
|---|---|
| Technical sections issued | 51 |
| Reached by a curated term | 18 exact + 4 at parent level |
| In the library but unreachable from these drawings | 21 |
| **Not in the library at all** | **8** |
| Sections surfaced that were *not* issued | 70 |
| **Recall** | **43%** |
| **Precision** | **23.9%** |

## A data defect found on the way

The spec volume writes sub-sections with a dot — `09 21 16.23` — while `data.js` uses a hyphen —
`09 21 16-23`. Treated naively these are different sections, which inflated both the miss count and
the false-positive count. Codes are now canonicalised before comparison. Worth normalising in the
library itself.

## The curation pass

An automated first pass proposed candidate terms for the 21 unreachable sections. Roughly a third
were usable; the rest were n-gram artefacts (`wall wall wall`), over-generic single words (`metal`,
`floor`, `concrete`), or plainly wrong targets (`fire protection sprinkler` proposed for a fire
extinguisher cabinet).

**This is the honest finding: extraction proposes, judgement disposes.** The review gate in the
`spec-library-curator` skill is not ceremony — without it the library would degrade.

18 mappings were accepted, each verified twice: the term appears on these drawings, and the section
appears in this project's issued list.

```
fire stopping             -> 07 84 00     signage                   -> 10 14 00
paint, painted            -> 09 91 00     gfrc, grc                 -> 03 49 00
access panel/panels/door  -> 08 31 00     steel stud framing        -> 09 22 16
stud framing              -> 09 22 16     plywood backing           -> 09 28 11
roller shade, roller shades -> 12 24 13   fire extinguisher cabinet -> 10 44 13
extinguisher cabinet      -> 10 44 13     polished concrete         -> 03 35 43
shaft wall                -> 09 21 16-23
```

Two proposals were **rejected by validation** because their target sections do not exist in
`sections` at all: `toilet partition` → `10 21 13.09` and `stone veneer` → `04 43 13`. The script
failed loudly rather than writing a dangling reference.

## Result after curation

| | before | after |
|---|---|---|
| Reached exactly | 18 | **28** |
| Unreachable backlog | 21 | **11** |
| **Recall** | 43% | **65%** |
| **Precision** | 23.9% | **32.4%** |
| Evaluation set score | 78.5% | **100%** (80 cases) |

Precision improved only because recall did — nothing was removed this pass. Cutting the 70
not-issued sections is a separate exercise and needs more than one project of evidence.

## Still missing after this pass

Eight issued sections have no entry in `sections` whatsoever, so no alias can ever reach them:

```
07 42 50  Metal Column Cladding          09 54 00  Specialty Ceilings
07 95 13  Interior Expansion Control     10 20 00  Interior Specialties
08 34 56  Security Gates                 10 26 13  Corner Guards
08 71 10  Door Hardware Schedule         27 41 16  Integrated Audio Visual Systems
```

Terms for several of these (`corner guard`, `column cladding`) *do* appear on the drawings. Adding
the sections is a prerequisite to curating them.

## Interpretation

43% recall means that on a real package, the app would have surfaced fewer than half the
specifications actually required. That is the number to drive down, and it is now measurable.

One project moved it 20 points. The next few will move it less as the easy wins are taken, and
progress will then depend on the harder judgement calls.

## Postscript — two false positives caught by human review

After the first pass, two results were flagged on sight: `stud framing` producing Rough Carpentry,
and `solid surfacing material` producing architectural woodwork. Both were real errors, both
pre-existed this work, and neither was detectable by the automated comparison — the first because
the section was plausible, the second because the section *was* issued and only the attribution was
wrong.

Checking them exposed a third thing: two of the auto-generated evaluation cases encoded those same
bad mappings as expected behaviour. A term co-occurring with an issued section is not proof the two
are linked, and an evaluation set built on that assumption inherits the error.

The loop is: extraction proposes, measurement ranks, **judgement decides**, and the evaluation set
records the decision so it cannot regress. Skipping the third step produces a library that scores
well against its own mistakes.
