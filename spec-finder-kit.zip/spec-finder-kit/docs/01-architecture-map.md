# Spec Finder — Architecture Map

Derived from `shadiaalkhaledi-dot/Spec-Search` @ `main`, single file `index.html` (423,009 chars).
Line numbers below refer to the **formatted** `app.js` (JS extracted from `index.html`, 15,546 lines).

---

## 1. What it is

A single-page, fully client-side app. A user types a term off a construction drawing — `expansion joint`,
`HM`, `IGU`, `curtain wall` — and gets back the MasterFormat specification section(s) that term implies,
plus the drawing sheets the term actually appears on, in context, with a link to the sheet.

No server. No build step. No network calls of any kind (verified: zero `fetch`, zero `XMLHttpRequest`,
zero `sendBeacon`, zero `<form action>`). The only external dependency is **pdf.js 3.11.174** loaded
from cdnjs, used for text extraction from uploaded drawing PDFs.

---

## 2. Shape of the file

| Region | Lines | Share | Contents |
|---|---|---|---|
| `const DB = {…}` | 1 – 14,287 | **92%** | Static spec library. Pure data, no logic. |
| Application logic | 14,288 – 15,546 | 8% | Everything the app actually does. |

This ratio is the single most useful fact about the codebase: almost all of it is a lookup table.
The program itself is about 1,260 lines.

---

## 3. Data model

`DB` has exactly three keys.

| Key | Type | Size | Shape |
|---|---|---|---|
| `DB.sections` | array | 464 | `{code, title, div, divName, mfr: string[], bod: string[]}` |
| `DB.aliases` | object | 3,254 | `keyword or phrase` → `section code[]` |
| `DB.kwByCode` | object | 449 | `section code` → `keyword[]` (reverse index of `aliases`) |

`code` is a MasterFormat number (`03 11 13`, sometimes suffixed `-00`, `-71`). `div` is the division,
`mfr` is acceptable manufacturers, `bod` is basis-of-design.

At load these are aliased to mutable globals `SECS`, `ALIASES`, `KWBYCODE`, and a `byCode` index is
built once. **User keyword edits mutate `ALIASES` and `KWBYCODE` in place**, so the in-memory data
diverges from `DB` as soon as anyone edits a keyword.

---

## 4. The seven tabs

| Tab | Element | What it does |
|---|---|---|
| Keyword → required spec | `#tab-lookup` | Single-term search. The core feature. |
| Batch check | `#tab-batch` | Paste a list of terms, get required sections + unmatched list. |
| Browse all sections | `#tab-browse` | Filter/sort all 464 sections; edit keywords; set manufacturer prefs. |
| Required specs | `#tab-scan` | Scans the whole uploaded drawing set and infers which sections are required. |
| Keyword glossary | `#tab-glossary` | Browse all 3,254 alias terms and what they map to. |
| Update drawings | `#tab-update` | PDF/JSON/TXT upload, plus "download updated index.html" self-bake. |
| Feedback | `#tab-feedback` | Flags raised against wrong results; local only. |

---

## 5. Core algorithm — `lookup(query)` (14,390 – 14,435)

The heart of the app. Returns the top 12 sections by accumulated score.

**Normalisation.** `nrm()` lowercases, replaces every non-`[a-z0-9 ]` character with a space, collapses
whitespace. `sing()` strips one trailing `s` from words longer than 3 characters. Both are applied to the
query, to every alias term, and to every section title.

**Pass 1 — find the longest matching alias** (14,405 – 14,410). Iterates all 3,254 alias keys, normalising
and tokenising each one, recording the greatest word-count among aliases whose every token matches some
query token.

**Pass 2 — score** (14,411 – 14,417). Iterates all 3,254 keys again. An alias qualifies when *every one*
of its tokens matches a query token — order-independent, no adjacency requirement. Token matching
(`tokMatch`, 14,401) is equality, or a prefix relation in either direction when both tokens are ≥4 chars.

```js
const base = 900 + tt.length * 300;
resolveCodes(ALIASES[term]).forEach((s, i) => add(s, base - i * 40, [term]));
```

So a two-word alias scores 1,500 and a one-word alias 1,200; within one alias, the author's ordering of
codes acts as a tie-break at 40 points per position. Scores **accumulate** per section code, so a section
hit by several aliases climbs.

**Pass 3 — title fallback** (14,417 – 14,433), suppressed entirely when a multi-word alias already matched:

- exact title substring containing the query, query >2 chars → +90
- per-token title hits → +40 each
- a query containing ≥4 consecutive digits that appear in the section code → +80

**Ranking.** `sort((a,b) => b.score - a.score).slice(0, 12)`.

**The confidence threshold is `score >= 70`** — used in three places (14,746, 14,748, 14,774) as a bare
literal. Below it, the UI withholds the "✓ Specification required" badge.

`resolveCodes()` (14,364) expands a code that isn't directly in `byCode` — first to children by `code.`
prefix (capped at 2), then to a loose fallback matching sections sharing the first 6 raw characters.

---

## 6. Drawing search

Two *different* mechanisms operate on the same text, which is worth knowing:

**Counting** — `drawingHits()` normalises the page text and uses a boundary-anchored regex
`(?:^|[^a-z0-9])PHRASE(?:[^a-z0-9]|$)`. This produces the hit count on each sheet badge.

**Highlighting** — `phraseRx()` / `allMatchIdx()` / `snipAt()` run against the *original, unnormalised*
text with a regex that joins escaped words with `[^A-Za-z0-9]+` and has **no boundary anchors at all**.
This produces the snippets and the "show all N matches" count.

The two counts are computed differently and can disagree. The highlighter can match inside a longer word.

Snippets take 70 chars before and `len+100` after, HTML-escape, then re-run the regex on the escaped
string to insert `<mark>`. Overlapping matches within 30 characters are collapsed.

Sheet links are `${PDF_URL}#page=${page}` when `PDF_URL` is set, otherwise plain text.

---

## 7. The scan — "Required specs"

The most ambitious feature and the one with the most inference in it.

**Loop shape:** iterates every one of the 3,254 alias terms (14,910) and tests each against every page.

**Demolition vs new work.** Pages are pre-classified — a sheet whose title/number matches `DEMO_SHEET`
is demolition; otherwise the page is checked for demolition and "to remain" language. For a term hit,
the code walks sentence-level segments: `"to remain"` segments are skipped, demolition-language segments
mark the hit as demo, others mark it new work. **If the term matched the page but no individual segment,
it defaults to new work.**

**`scanConf()` (14,802 – 14,808) is a two-value classifier, not a score**, despite the name:

```js
const specialized = SPECIAL.test(sec.title);
const hasSpecific = termsArr.some((x) => x.includes(" "));
if (specialized && !hasSpecific) return "maybe";
const allBroad = termsArr.every((x) => !x.includes(" ") && (ALIASES[x] || []).length > 3);
if (allBroad) return "maybe";
return "likely";
```

A section is downgraded to `maybe` if its title is in the `SPECIAL` list and nothing multi-word matched,
or if every matched term is a single word mapping to more than 3 sections. Otherwise `likely`.

**Match strength plays no part.** A section found on 40 sheets via one generic term is classified
identically to one found on a single sheet. The `#scanHideMaybe` checkbox filters to `likely` only.

The demolition block is hardcoded to section `02 41 19`, with a hand-written stub if that code is absent.

---

## 8. PDF ingest

`handleFile()` (15,224) branches on extension: `.json` parses directly, `.txt` splits on form-feed `\f`
as page breaks, anything else goes to `indexPdf()`.

`indexPdf()` (15,117) guards that `pdfjsLib` exists, pins the worker to the cdnjs 3.11.174 URL, reads the
file as a `Uint8Array`, then per page calls `getTextContent()` and flattens with
`tc.items.map(it => it.str).join(" ")`. Progress bar updates per page; every 4th page it yields with
`await new Promise(r => setTimeout(r))` to keep the UI alive.

**Record shape** (`recFromFlat`, 15,108): `{page, sheet, disc, title, text}`

- `sheet` — last `SHEET_RX` match in the flattened text, `""` if none
- `disc` — first character of `sheet`, or `"?"`
- `title` — text captured between the literal markers `SHEET TITLE` and `LOCATION PROJECT`
- `text` — the entire flattened page

Scanned PDFs with no text layer produce zero records and a specific message telling the user to OCR.
The whole of `handleFile` sits in one `try/catch`; any failure surfaces as `"Could not load: …"`.

---

## 9. Persistence — six localStorage keys

| Key | Written by | Read by | Contents |
|---|---|---|---|
| `sf_dwg` | `saveLocal` 15,142 | `applySaved` 15,187 | Full `DRAWINGS` array **including every page's complete text** |
| `sf_name` | `saveLocal` 15,143 | `applySaved` 15,192 | Display name of the loaded set |
| `sf_url` | `saveLocal` 15,144 | `applySaved` 15,193 | PDF URL, but **never a `blob:` URL** |
| `sf_mfr` | `saveMfr` 14,464 | `loadMfr` 14,458 | Per-section manufacturer preferences |
| `kwedits` | `saveEdits` 14,302 | `loadEdits` 14,295 | User keyword add/remove edits |
| `sf_flags` | `saveFlags` 15,376 | `loadFlags` 15,370 | Feedback flags |

`resetToBuilt()` clears `sf_dwg`, `sf_name`, `sf_url` together. "Reset all" for keyword edits removes
`kwedits` and reloads the page.

**Feedback never leaves the browser.** Flags are written to `sf_flags` and the only egress is a manual
"Export feedback (JSON)" download. If a user flags results and never exports — or clears site data —
that feedback is gone, with no server-side record.

---

## 10. Fragilities, ranked

Verified against source unless marked otherwise.

1. **`sf_dwg` stores the full text of every drawing page.** A large set will exceed the ~5–10 MB
   localStorage quota. `saveLocal` catches the failure and returns `false`, and the UI does surface a
   note — but `catch (e) { return false; }` discards the error entirely, so there is no diagnostic.

2. **Two disagreeing match counters** (§6). The badge count and the snippet count use different regexes
   against differently-normalised text. The highlighter has no word-boundary anchors and can match
   inside a longer word.

3. **`esc()` escapes only `&`, `<`, `>`** (14,440) — not quotes. It is used to build attribute values
   such as `data-name="${esc(n)}"` where `n` is a user-typed manufacturer name persisted in `sf_mfr`.
   A name containing `"` can break out of the attribute on re-render. Self-inflicted and local-only,
   but it is real attribute injection.

4. **`scanConf` ignores evidence strength** (§7). Named like a confidence score, behaves like a
   two-value heuristic over section titles and term genericness.

5. **Full corpus rescanned on every keystroke.** `lookup()` walks all 3,254 aliases *twice*, re-normalising
   and re-tokenising every term both times, with no memoisation. A 120 ms debounce hides it, but the
   normalised token lists could trivially be computed once at load.

6. **The self-bake is a blind regex.** `dlBtn.onclick` rewrites the page's own source with
   `html.replace(/const DRAWINGS = [\s\S]*?;\nconst DISC/, …)`. `String.replace` with no match returns
   the input unchanged and throws nothing. **Reformatting broke this** — see §11. Patched, but the
   silent-failure design remains: consider adding a match check before writing the blob.

7. **`sing()` is naive** — `w.length > 3 && w.endsWith("s")` strips the `s`, so `glass` → `glas`,
   `truss` → `trus`, `brass` → `bras`. Applied symmetrically to queries and aliases, so mostly benign;
   combined with the ≥4-char prefix rule in `tokMatch` it widens matching more than intended.

8. **Segment-miss defaults to new work** (§7). A term matching a page but no sentence segment is assumed
   new scope, which can misfile demolition-only terms.

9. **Unconfirmed destructive reset.** "Reset all" wipes `kwedits` and reloads with no `confirm()`, while
   the far less costly "Clear flags" does confirm.

10. **`blob:` URLs are deliberately not persisted**, so after a reload the drawing *text* survives but
    sheet links have nothing to point at until the same PDF is re-uploaded. No warning at reload time.

---

## 11. The reformat broke the self-bake — found and fixed

Token-level equivalence is not enough for this file, because one feature reads its **own source text**.
`dlBtn.onclick` matched `/const DRAWINGS = [\s\S]*?;\nconst DISC/` — a newline immediately followed by
`const DISC` at column zero. After formatting, that line is indented six spaces inside `<script>`, so
the regex no longer matched. `String.replace` returns the input unchanged on no match, so
"Download updated index.html" would have silently produced a file with **empty drawing data** and no
error anywhere.

Two lines changed to fix it:

```js
// was
html = html.replace(
  /const DRAWINGS = [\s\S]*?;\nconst DISC/,
  "const DRAWINGS = " + JSON.stringify(DRAWINGS) + ";\nconst DISC",
);
// now
html = html.replace(
  /const DRAWINGS = [\s\S]*?;(\s*)const DISC/,
  (m, gap) => "const DRAWINGS = " + JSON.stringify(DRAWINGS) + ";" + gap + "const DISC",
);
```

The capture group makes it indentation-agnostic, so it works against both the original and any future
reformatting. Switching to a **function replacement** also fixes a separate latent bug: as a string,
`$&` or `$1` occurring inside drawing text or a PDF URL would have been interpreted as replacement
patterns and corrupted the output. The `PDF_URL` replacement got the same treatment.

Verified: regex matches, a round-trip insert lands real data, indentation is preserved, and text
containing `$` and `&` survives intact.

---

*Produced by three parallel readers over disjoint slices of the logic, plus a structural pass over the
data region. The 14,287-line `DB` constant was characterised by schema sampling and never read.*
