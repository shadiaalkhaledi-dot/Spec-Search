# Diagrams

`user-loop.svg` — what happens at runtime when someone uses Spec Finder. Upload, extraction,
lookup, and the two kinds of answer it can give. Bold outline marks `data.js` and the paths that
feed it; the dashed box is the feedback signal that is currently collected and then lost.

`learning-loop.svg` — how `data.js` improves. A finished project's drawings and its issued spec
list are compared against the current library, results sort into four buckets, and two gates stand
between a proposal and a commit: your judgement, and the evaluation set.

Both open in any browser. Self-contained, no external assets.
