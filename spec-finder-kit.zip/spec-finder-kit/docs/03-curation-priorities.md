# Spec Finder — curation priorities

After the precision change, only terms in `data.js -> aliases` can be returned as a **required**
specification. Everything else appears as an unbadged suggestion.

These are the words that appear in three or more section titles but have **no alias entry**, so
someone typing them today gets "no curated match". Ordered by how many sections use the word,
which is a rough proxy for how often it gets typed.

For each, decide which section(s) it should actually point at and add it. The app now offers a
one-click **+ Add** button on every suggestion, which writes to your local edit store; export that
and fold it into `data.js`.

| word | appears in N section titles | what the title-only fallback currently suggests |
|---|---|---|
| `concrete` | 51 | 03 38 00, 03 01 30-00, 03 01 30-71 |
| `wall` | 23 | 07 42 13-19, 03 05 34, 07 42 13 |
| `doors` | 23 | 08 14 73, 08 11 13, 08 11 13-16 |
| `glass` | 21 | 03 25, 03 49 00, 04 23 00 |
| `metal` | 21 | 05 05 00, 05 05 13, 05 05 19 |
| `wood` | 20 | 07 46 23-13, 08 14 73, 06 03 00 |
| `steel` | 19 | 05 08 10, 05 12 00, 05 12 33 |
| `masonry` | 17 | 04 01 20-52, 04 01 42, 04 01 52 |
| `panels` | 16 | 07 42 13-19, 03 47 13, 06 42 00 |
| `membrane` | 15 | 03 15 26, 06 16 43-13, 07 01 50 |
| `roofing` | 15 | 03 05 16, 07 01 50, 07 01 52 |
| `flooring` | 14 | 09 65 00, 09 05 58, 09 05 61 |
| `equipment` | 14 | 11 12 00, 11 13 00, 11 17 00 |
| `coatings` | 13 | 05 05 13, 07 18 13, 07 18 16-00 |
| `bridges` | 12 | 03 01 43, 03 11 43, 03 11 43-13 |
| `architectural` | 11 | 03 11 16, 03 33 00, 03 45 00 |
| `interior` | 11 | 03 35 11, 03 35 45, 06 20 23 |
| `exterior` | 11 | 06 20 13, 07 24 19, 07 44 19 |
| `precast` | 10 | 03 01 30-71, 03 01 40-51, 03 05 34 |
| `waterproofing` | 10 | 03 05 16, 07 08 25, 07 13 52 |
| `accessories` | 10 | 11 53 43, 03 11 43, 03 15 00 |
| `unit` | 9 | 04 01 20-52, 04 01 52, 04 21 29-00 |
| `stone` | 9 | 04 01 42, 04 43 13-00, 04 43 13-13 |
| `applied` | 9 | 05 05 13, 07 14 13, 07 14 16 |
| `finishing` | 8 | 03 35 11, 03 35 13, 03 35 33 |
| `gypsum` | 8 | 03 54 13, 06 16 43, 06 16 43-13 |
| `veneer` | 8 | 04 21 13, 04 21 31, 04 22 16 |
| `common` | 8 | 05 05 00, 05 05 19, 05 05 31 |
| `work` | 8 | 03 11 43, 05 05 00, 05 05 19 |
| `results` | 8 | 05 05 00, 05 05 19, 05 05 31 |
| `aluminum` | 8 | 05 36 13, 07 46 33, 08 18 16 |
| `fabrications` | 8 | 05 50 00, 05 50 43, 05 58 00 |
| `control` | 8 | 08 34 73, 08 88 26, 09 65 36 |
| `floor` | 7 | 09 65 00, 03 35 11, 03 35 13 |
| `plastic` | 7 | 03 35 11, 06 60 00, 06 82 00 |
| `sheet` | 7 | 07 13 52, 07 17 16, 07 62 00 |
| `insulation` | 7 | 07 21 13, 07 21 16, 07 21 19 |
| `panel` | 7 | 07 42 13-19, 03 47 13, 06 26 13 |
| `siding` | 7 | 07 46 21, 07 46 23-13, 07 46 33 |
| `door` | 7 | 08 14 73, 08 06 10, 08 06 71 |
| `elevators` | 7 | 14 01 20, 14 05 20, 14 08 20 |
| `place` | 6 | 03 01 30-00, 03 01 43, 03 11 13 |
| `fibre` | 6 | 03 25, 03 49 00, 06 82 00 |
| `high` | 6 | 03 31 24, 03 31 33, 03 35 13 |
| `performance` | 6 | 03 31 24, 03 45 19, 07 08 13 |
| `protection` | 6 | 03 31 33, 10 26 23-13, 10 44 13 |
| `composite` | 6 | 05 36 13, 06 26 19, 07 17 16 |
| `board` | 6 | 06 26 13, 06 26 19, 07 21 13 |
| `building` | 6 | 03 38 00, 07 05 11, 07 08 11 |
| `bituminous` | 6 | 07 11 13, 07 13 52, 07 51 00 |
| `fluid` | 6 | 07 14 13, 07 14 16, 07 14 34 |
| `zinc` | 6 | 07 46 21, 07 41 13-19, 07 42 13-19 |
| `sliding` | 6 | 08 14 73, 08 18 16, 08 32 13-16 |
| `resistant` | 6 | 08 39 53, 08 88 13, 09 61 13-13 |
| `resilient` | 6 | 09 65 00, 09 64 53, 09 65 13 |
| `signage` | 6 | 10 14 00, 10 14 05, 10 14 13-13 |
| `testing` | 5 | 05 08 10, 03 08 30, 07 08 13 |
| `reinforced` | 5 | 03 25, 03 49 00, 06 82 00 |
| `post` | 5 | 03 38 00, 03 41 36, 05 05 23 |
| `tensioned` | 5 | 03 38 00, 03 41 33, 03 41 36 |


_141 words with no alias entry in total; the 60 most common are listed._
