# Spec Finder — Learning Loop Blueprint

How the system improves, what each piece does, and what is still missing.

---

## 1. Two loops, one file boundary

**Runtime loop — the user.** Someone uploads a drawing set. pdf.js extracts the text. They type a
term. The app answers from the curated keyword library and shows which sheets the term appears on.
This runs entirely in their browser and touches nothing on a server.

**Learning loop — you.** After a project closes, its drawings and its *actually issued* spec list
become evidence. That evidence improves the library. The improved library goes back to the site.

The split we made is what keeps these separate:

| File | Contains | Changes |
|---|---|---|
| `index.html` | Application code. No spec content. | Rarely — only when behaviour changes |
| `data.js` | The entire spec library. Data only. | Often — every curation pass |

**This is the answer to "does index.html stay the same?" — yes.** Curation never touches it. You
upload only `data.js`. `index.html` changes only when you want the app itself to behave differently,
which is a separate decision on a separate cadence.

---

## 2. What actually happens when you hand Claude a project

You provide two things:

- **A** — the drawing set (PDF)
- **B** — the specification list actually issued for that project (section numbers and titles)

B is the ground truth. Without it there is nothing to learn from; drawings alone only tell you what
words exist, not which specs they implied.

### Step by step

**1. Extract terms from the drawings.**
Pull text from the PDF, then harvest candidate terms — material callouts, keynotes, schedule
entries, abbreviations. Not every word: the ones a person would plausibly type into the app.

**2. Extract issued section codes from the spec list.**
Normalise to the same `NN NN NN` form used in `data.js`.

**3. Ask the current library what it would have said.**
Run each extracted term through the existing `lookup()`. This is the critical step and it is what
makes the loop measurable rather than vibes-based. Every term lands in one of four buckets:

| Bucket | Meaning | Action |
|---|---|---|
| **Confirmed** | Term returns a section that *was* issued | Nothing. Evidence the library is right. |
| **Gap** | Term returns nothing curated, but a plausible section *was* issued | Candidate alias to add |
| **Wrong** | Term returns a section that was *not* issued, while another was | Candidate to retarget or remove |
| **Orphan** | A section was issued but no drawing term reaches it | Find the term that should |

**4. Propose a diff — never apply silently.**
Output is a list of additions and removals against `data.js`, each with the evidence behind it and a
confidence label. You approve before anything is written.

**5. Apply by script, never by hand.**
Load `data.js`, apply changes to `aliases`, rebuild `kwByCode` from `aliases` so the two cannot
drift, verify every referenced code exists in `sections`, re-sort keys, write back.

**6. Regression test before committing.**
Run `lookup()` across a sample before and after. Report what changed and whether it was intended.
Any unexplained movement means stop.

**7. Record provenance.**
Which project taught which alias. Without this you cannot roll back one project's contribution when
it turns out to have been wrong.

---

## 3. The honest limit — one project is weak evidence

Knowing that `expansion joint` appeared on the drawings and that `07 95 00` was issued does **not**
prove they are connected. Both facts are true of the project; the link between them is inference.

A single project produces *candidates*, not proof. The signal gets real through repetition — a term
that co-occurs with the same section across four projects is a genuine mapping; across one it is a
guess.

Two consequences:

- **Label confidence honestly.** Additions from one project should be marked as such, not merged
  invisibly into the same pool as well-established mappings.
- **The loop compounds.** Project two is worth more than project one, and project six is worth more
  than project five. Expect the first pass to feel underwhelming.

Where Claude adds real value is step 4's judgement: given a section that was issued and the drawing
context around it, deciding *which* words a person would actually have typed to find it. That is
reading comprehension over construction documents, and it is the part that is hard to automate any
other way.

---

## 4. Release model

```
curation pass  ->  data.js only   ->  commit  ->  live
app change     ->  index.html     ->  commit  ->  live  (rare, needs smoke test)
```

Both files must exist in the repo root together. `index.html` now fails with a clear message rather
than a console error if `data.js` is missing, but a commit that adds one without the other still
breaks the site for the duration of the gap. Commit them together, or `data.js` first.

---

## 5. Setup — project and skill

**Cowork project.** Create one for Spec-Search. Attach as project knowledge:

- `SpecFinder-architecture-map.md` — how the app works
- this blueprint
- the current `data.js` (or the repo sync)

**Skill.** `spec-library-curator` is already saved to your account. It carries the procedure above —
baseline first, four-bucket classification, script-not-hand edits, `kwByCode` rebuilt from `aliases`,
regression test before commit, changelog for provenance. Invoke it when you start a curation pass.

You do not need a new skill per project. One skill, many projects.

---

## 6. What works, what doesn't, what is missing

### Works

- Only curated mappings can be badged "required". Title-text guesses are visibly demoted.
- The library is a separate, sorted, diffable file. Curation is now a reviewable pull request.
- `kwByCode` is rebuilt from `aliases`, so the reverse index cannot silently drift.
- A regression harness exists — `lookup()` can be run headlessly against any version of the library.
- Drawing storage moved to IndexedDB, so large sets stop silently failing to persist.

### Doesn't work well

- **Recall on common words.** 141 words appearing in three or more section titles have no alias at
  all — `concrete`, `wall`, `doors`, `glass`, `metal`, `wood`, `steel`, `masonry`, `roofing`,
  `flooring`, `waterproofing`. Someone typing these gets "no curated match" today. This is the first
  thing a curation pass should fix, and `curation-priorities.md` is the ordered backlog.
- **In-app feedback is a dead end.** Users can flag a wrong result, but the flag is written to their
  browser and never leaves it. Unless they manually export a JSON file and send it to you, you will
  never see it. The most valuable signal in the system is currently being discarded.
- **Manufacturer and basis-of-design data has no loop at all.** `mfr` and `bod` are static. Nothing
  updates them from projects.
- **The scan's demolition-versus-new-work inference is unvalidated.** It reads sentence context for
  demolition language and defaults to "new work" when uncertain. Plausible, never tested against a
  real project's outcome.

### Missing entirely — and this is the important one

**There is no evaluation set.** Nothing in the repo says "these 80 terms should return these
sections." Without it:

- "fewer false positives" is an impression, not a measurement
- there is no way to prove a curation pass helped rather than hurt
- there is no regression safety net beyond "did the numbers move"

The single highest-value thing to build next is a small labelled test file — 50 to 100 real
`term -> correct section` pairs drawn from finished projects, committed alongside `data.js`. Then
every change is scored, and the loop becomes an engineering process rather than a judgement call.

This should probably come *before* bulk curation, so the first big pass can be measured.

---

## 7. What to send for the first real pass

- One finished project's **drawing set** (PDF; architectural is enough to start)
- That project's **issued specification list** — section numbers and titles, in any format
- Optionally, any terms you already know the app gets wrong

One project is enough to prove the pipeline and to build the first version of the evaluation set.
Two or three make the additions trustworthy.
